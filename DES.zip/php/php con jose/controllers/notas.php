<?php
$seccion = 'Notas';

require_once 'views/notas.view.php';