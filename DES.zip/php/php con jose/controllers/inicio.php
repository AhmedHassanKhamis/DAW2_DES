<?php
$seccion = 'Inicio';

require_once 'views/inicio.view.php';