<?php
$seccion = 'Informacion';

require_once 'views/info.view.php';