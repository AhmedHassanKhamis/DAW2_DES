<?php

$seccion = 'Contacto';
require_once 'views/contacto.view.php';