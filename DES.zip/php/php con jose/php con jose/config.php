<?php
return [
    'host' => 'localhost',
    'dbname' => 'base',
    'username' => 'php',
    'password' => 'php',
    'port' => 3306

];
?>
