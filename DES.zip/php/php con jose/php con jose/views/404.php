<?php

require 'partials/cabecera.php';
?>

<div class="bg-body-tertiary p-5 rounded">
    <h1>404</h1>
    <p>
        La pagina que estás buscando no existe.
    </p>

    <p><a href="/">Volver a la pagina de inicio</a></p>
</div>
<?php
require 'partials/pie.php';