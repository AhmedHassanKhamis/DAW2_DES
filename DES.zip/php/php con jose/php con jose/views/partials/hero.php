<header class="bg-info p-2  mt-2 rounded">
    <h2 class="h2"><?= $seccion ?></h2>
</header>