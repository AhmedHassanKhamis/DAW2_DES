<footer class="bg-body-secondary fixed-bottom"><h3>Footer</h3></footer>
</body>
</html>