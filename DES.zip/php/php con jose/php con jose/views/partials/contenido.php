<main>
  <p class="h4">Estas en la seccion de <?= $seccion?></p>
</main>